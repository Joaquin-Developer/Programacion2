/* 5124352 */

#include "../include/aplicaciones.h"
#include "../include/cadena.h"
#include "../include/iterador.h"

TCadena insertarAlFinal(nat natural, double real, TCadena cad)
{
    return NULL;
}

TCadena removerPrimero(TCadena cad)
{
    return NULL;
}

TCadena copiaCadena(TCadena cad)
{
    return NULL;
}

TIterador reversoDeIterador(TIterador iter)
{
    return NULL;
}
