/* 5124352 */

#include "../include/colCadenas.h"

struct _rep_colCadenas
{
};

TColCadenas crearColCadenas()
{
    return NULL;
}

void liberarColCadenas(TColCadenas col)
{
}

TCadena cadenaDeColCadenas(nat pos, TColCadenas col)
{
    return NULL;
}

nat cantidadColCadenas(nat pos, TColCadenas col)
{
    return 0;
}

bool estaEnColCadenas(nat natural, nat pos, TColCadenas col)
{
    return false;
}

TColCadenas insertarEnColCadenas(nat natural, double real, nat pos,
                                 TColCadenas col)
{
    return NULL;
}

TInfo infoEnColCadenas(nat natural, nat pos, TColCadenas col)
{
    return NULL;
}

TColCadenas removerDeColCadenas(nat natural, nat pos, TColCadenas col)
{
    return NULL;
}
